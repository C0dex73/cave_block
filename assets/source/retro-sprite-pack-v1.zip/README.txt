# Retro Sprite Pack

Hey, thanks so much for trying out my retro-style sprite pack. It's designed to
work nicely with my Retro Texture Pack, perfect for creating an awesome 90s
style FPS!!!

## Contents

There is currently a total of *22* unique sprites.

## License

See the LICENSE.txt file included in this asset pack for full details, but in
short you're welcome to use the texture in any non-commercial and commercial
works. You may not, however, distribute the texture pack in any format.

## Contact

If you encounter any problems, have any questions or have some feedback,
you can reach me here:

- Twitter: https://twitter.com/MartiansGame
- Discord: https://discord.gg/bmwsKU6dqP
- Website: https://little-martian.dev
- Mail: craig@craigsmith.info

Thank you!